const express = require('express');
const router = express.Router();
const controller = require('../controllers/transport.controller');

// GET routes
router.get('/intersections/:id/connected', controller.getConnectedIntersections);
router.get('/path/shortest', controller.getShortestPath);
router.get('/roads/fast', controller.getFastRoads);
router.get('/roads/fast', controller.getFastRoads);
router.get('/intersections/most-connected', controller.getMostConnectedIntersections);
router.get('/stats', controller.getNetworkStats);

// POST/PUT routes
router.post('/roads/create', controller.createOrUpdateRoute);

module.exports = router;