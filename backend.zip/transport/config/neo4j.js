const neo4j = require('neo4j-driver');
require('dotenv').config();

const driver = neo4j.driver(
  process.env.NEO4J_URI || 'bolt://localhost:7687',
  neo4j.auth.basic(
    process.env.NEO4J_USER || 'neo4j',
    process.env.NEO4J_PASSWORD || 'password'
  )
);

const getSession = () => driver.session();

// Test de connexion (optionnel)
driver.verifyConnectivity()
  .then(() => console.log('✅ Neo4j connecté avec succès'))
  .catch(err => console.error('❌ Erreur de connexion Neo4j:', err));

module.exports = { driver, getSession };