const { getSession } = require('../config/neo4j');

// Requête 1 : Intersections directement connectées (Requête simple)
exports.getConnectedIntersections = async (req, res) => {
  const session = getSession();
  try {
    const { id } = req.params;
    const result = await session.run(
      `MATCH (a:Intersection {id: $id})-[:ROAD]->(b)
       RETURN b.id AS voisin`,
      { id: parseInt(id) }
    );
    
    const intersections = result.records.map(record => {
      const value = record.get('voisin');
      return typeof value === 'object' && value.toNumber ? value.toNumber() : value;
    });
    
    res.json({ success: true, data: intersections });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  } finally {
    await session.close();
  }
};

// Requête 2 : Chemin le plus court (Requête de chemin)
exports.getShortestPath = async (req, res) => {
  const session = getSession();
  try {
    const { start, end } = req.query;
    const result = await session.run(
      `MATCH (start:Intersection {id: $start}), (end:Intersection {id: $end}),
       p = shortestPath((start)-[:ROAD*]->(end))
       RETURN [n IN nodes(p) | n.id] AS chemin, length(p) AS nb_segments`,
      { start: parseInt(start), end: parseInt(end) }
    );
    
    if (result.records.length === 0) {
      return res.json({ success: true, data: null, message: "Aucun chemin trouvé" });
    }
    
    const record = result.records[0];
    
    // Convertir les valeurs Neo4j en nombres
    const cheminRaw = record.get('chemin');
    const chemin = cheminRaw.map(node => 
      typeof node === 'object' && node.toNumber ? node.toNumber() : node
    );
    
    const nbSegments = record.get('nb_segments');
    const nb_segments = typeof nbSegments === 'object' && nbSegments.toNumber 
      ? nbSegments.toNumber() 
      : nbSegments;
    
    res.json({
      success: true,
      data: {
        chemin: chemin,
        nb_segments: nb_segments
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  } finally {
    await session.close();
  }
};

// Hooks en haut du composant
const [minSpeed, setMinSpeed] = useState('50');
const [maxSpeed, setMaxSpeed] = useState('120');
const [minLanes, setMinLanes] = useState('2');
const [fastRoads, setFastRoads] = useState([]);
const [loading, setLoading] = useState(false);

// Fonction API
const loadFastRoads = async () => {
  setLoading(true);
  try {
    const response = await transportAPI.getFastRoads(Number(minSpeed), Number(maxSpeed), Number(minLanes));
    setFastRoads(response.data.data.slice(0, 10));
  } catch (error) {
    Alert.alert('Erreur', 'Impossible de charger les routes');
  } finally {
    setLoading(false);
  }
};

// Rendu
const renderContent = () => {
  if (activeTab === 'roads') {
    return (
      <View style={styles.content}>
        <Text style={styles.sectionTitle}>🚗 Routes rapides</Text>

        <View style={styles.row}>
          <TextInput
            style={[styles.input, styles.halfInput]}
            value={minSpeed}
            onChangeText={setMinSpeed}
            placeholder="Vitesse min"
            keyboardType="numeric"
          />
          <TextInput
            style={[styles.input, styles.halfInput]}
            value={maxSpeed}
            onChangeText={setMaxSpeed}
            placeholder="Vitesse max"
            keyboardType="numeric"
          />
        </View>

        <TextInput
          style={styles.input}
          value={minLanes}
          onChangeText={setMinLanes}
          placeholder="Voies min"
          keyboardType="numeric"
        />

        <TouchableOpacity style={styles.button} onPress={loadFastRoads} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Recherche...' : 'Rechercher'}</Text>
        </TouchableOpacity>

        <ScrollView style={styles.resultScroll}>
          {fastRoads.map((road, index) => (
            <View key={index} style={styles.roadCard}>
              <Text style={styles.roadText}>
                {formatValue(road.source)} → {formatValue(road.target)}
              </Text>
              <Text style={styles.roadDetails}>
                {formatValue(road.length)} km • {formatValue(road.speed_limit)} km/h • {formatValue(road.lanes)} voies
              </Text>
            </View>
          ))}
        </ScrollView>
      </View>
    );
  }

  
};



// Requête 4 : Intersections les plus connectées (Requête d'agrégation)
exports.getMostConnectedIntersections = async (req, res) => {
  const session = getSession();
  try {
    const { limit = 10 } = req.query;
    const result = await session.run(
      `MATCH (n:Intersection)-[r:ROAD]->()
       RETURN n.id AS intersection, COUNT(r) AS nombre_connexions
       ORDER BY nombre_connexions DESC
       LIMIT $limit`,
      { limit: parseInt(limit) }
    );
    
    const intersections = result.records.map(record => ({
      id: typeof record.get('intersection') === 'object' 
        ? record.get('intersection').toNumber() 
        : record.get('intersection'),
      connections: record.get('nombre_connexions').toNumber()
    }));
    
    res.json({ success: true, data: intersections });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  } finally {
    await session.close();
  }
};

// Requête 5 : Créer/Mettre à jour une route (Requête de modification)
exports.createOrUpdateRoute = async (req, res) => {
  const session = getSession();
  try {
    const { sourceId, targetId, length, speedLimit, lanes } = req.body;
    
    const result = await session.run(
      `MATCH (a:Intersection {id: $sourceId}), (b:Intersection {id: $targetId})
       MERGE (a)-[r:ROAD]->(b)
       SET r.length = $length,
           r.speed_limit = $speedLimit,
           r.lanes = $lanes
       RETURN a.id AS source, b.id AS target, r.length AS length, 
              r.speed_limit AS speed, r.lanes AS lanes`,
      { 
        sourceId: parseInt(sourceId), 
        targetId: parseInt(targetId),
        length: parseFloat(length),
        speedLimit: parseInt(speedLimit),
        lanes: parseInt(lanes)
      }
    );
    
    if (result.records.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: "Une ou les deux intersections n'existent pas" 
      });
    }
    
    const record = result.records[0];
    res.json({ 
      success: true, 
      message: "Route créée ou mise à jour avec succès",
      data: {
        source: typeof record.get('source') === 'object' 
          ? record.get('source').toNumber() 
          : record.get('source'),
        target: typeof record.get('target') === 'object' 
          ? record.get('target').toNumber() 
          : record.get('target'),
        length: record.get('length'),
        speed_limit: record.get('speed'),
        lanes: record.get('lanes')
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  } finally {
    await session.close();
  }
};

// Statistiques globales du réseau
exports.getNetworkStats = async (req, res) => {
  const session = getSession();
  try {
    const result = await session.run(
      `MATCH (n:Intersection)
       OPTIONAL MATCH ()-[r:ROAD]->()
       RETURN COUNT(DISTINCT n) AS total_intersections,
              COUNT(r) AS total_roads,
              AVG(r.speed_limit) AS avg_speed,
              AVG(r.length) AS avg_length`
    );
    
    const record = result.records[0];
    res.json({
      success: true,
      data: {
        total_intersections: record.get('total_intersections').toNumber(),
        total_roads: record.get('total_roads').toNumber(),
        avg_speed: record.get('avg_speed'),
        avg_length: record.get('avg_length')
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  } finally {
    await session.close();
  }
};