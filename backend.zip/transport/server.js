const express = require('express');
const cors = require('cors');
require('dotenv').config();

const transportRoutes = require('./routes/transport.routes');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/transport', transportRoutes);

// Route de test
app.get('/', (req, res) => {
  res.json({ 
    message: '🚗 API Transport Network en ligne !',
    endpoints: {
      stats: '/api/transport/stats',
      connected: '/api/transport/intersections/:id/connected',
      shortestPath: '/api/transport/path/shortest?start=0&end=90',
      fastRoads: '/api/transport/roads/fast?minSpeed=50&minLanes=2',
      mostConnected: '/api/transport/intersections/most-connected?limit=10',
      updateSpeed: 'PUT /api/transport/roads/update-speed'
    }
  });
});

// Gestion des erreurs 404
app.use((req, res) => {
  res.status(404).json({ 
    success: false, 
    message: 'Route non trouvée' 
  });
});

// Démarrage du serveur
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
  console.log(`🌐 Accessible via http://192.168.11.131:${PORT}`);
  console.log(`📊 Stats disponibles sur http://localhost:${PORT}/api/transport/stats`);
});